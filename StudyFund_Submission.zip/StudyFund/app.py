"""Read-only Flask gateway. Wallets, never this server, authorize transactions."""
import json
import logging
import os
from pathlib import Path
from functools import wraps
from urllib.parse import urlparse

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from web3 import Web3

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / '.env')
ABI = json.loads((BASE / 'abi/StudyFund.json').read_text(encoding='utf-8'))


def create_app(overrides=None, w3_override=None):
    app = Flask(__name__)
    app.config.update(
        RPC_URL=os.getenv('RPC_URL', ''),
        CONTRACT_ADDRESS=os.getenv('CONTRACT_ADDRESS', ''),
        CHAIN_ID=int(os.getenv('CHAIN_ID', '11155111')),
        DEPLOYMENT_BLOCK=int(os.getenv('DEPLOYMENT_BLOCK', '0')),
        LOG_BLOCK_RANGE=int(os.getenv('LOG_BLOCK_RANGE', '1000')),
        ENABLE_DEPLOY_UI=os.getenv('ENABLE_DEPLOY_UI', 'false').lower() == 'true',
        MAX_CONTENT_LENGTH=16384,
    )
    if overrides:
        app.config.update(overrides)
    if not 1 <= app.config['LOG_BLOCK_RANGE'] <= 10000:
        raise ValueError('LOG_BLOCK_RANGE must be between 1 and 10000')
    if app.config['DEPLOYMENT_BLOCK'] < 0:
        raise ValueError('DEPLOYMENT_BLOCK cannot be negative')
    w3 = w3_override
    if w3 is None and app.config['RPC_URL']:
        if urlparse(app.config['RPC_URL']).scheme not in ('http', 'https'):
            raise ValueError('RPC_URL must be an HTTP(S) endpoint')
        w3 = Web3(Web3.HTTPProvider(app.config['RPC_URL'], request_kwargs={'timeout': 8}))

    def contract():
        address = app.config['CONTRACT_ADDRESS']
        if w3 is None or not Web3.is_address(address) or int(address, 16) == 0:
            raise RuntimeError('not_configured')
        if w3.eth.chain_id != app.config['CHAIN_ID']:
            raise RuntimeError('wrong_chain')
        if not w3.eth.get_code(Web3.to_checksum_address(address)):
            raise RuntimeError('no_contract')
        return w3.eth.contract(address=Web3.to_checksum_address(address), abi=ABI)

    def guarded(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except ValueError:
                return jsonify(error='invalid_request', message='Check the wallet address and pagination values.'), 400
            except RuntimeError as exc:
                code = str(exc) if str(exc) in ('not_configured', 'wrong_chain', 'no_contract') else 'rpc_unavailable'
                return jsonify(error=code, message='Blockchain configuration or connection is unavailable.'), 503
            except Exception:
                # Do not expose RPC URLs (which can contain provider credentials).
                app.logger.warning('Blockchain read failed; details withheld to protect RPC credentials.')
                return jsonify(error='rpc_unavailable', message='Unable to read the blockchain. Please retry.'), 503
        return wrapper

    def address_arg():
        address = request.args.get('address', '')
        if not Web3.is_address(address):
            raise ValueError('address')
        return Web3.to_checksum_address(address)

    def integer_arg(key, default, low, high):
        value = int(request.args.get(key, default))
        if not low <= value <= high:
            raise ValueError(key)
        return value

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        if request.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.get('/')
    def index():
        return render_template('index.html')

    @app.get('/health')
    def health():
        return jsonify(status='ok', service='StudyFund', note='Liveness only; use /api/status for blockchain readiness.')

    @app.get('/api/config')
    def config():
        address = app.config['CONTRACT_ADDRESS']
        return jsonify(chainId=app.config['CHAIN_ID'], contractAddress=address,
                       configured=bool(w3 and Web3.is_address(address) and int(address, 16)),
                       explorer='https://sepolia.etherscan.io' if app.config['CHAIN_ID'] == 11155111 else '', abi=ABI)

    @app.get('/api/status')
    @guarded
    def status():
        c = contract()
        block = w3.eth.get_block('latest')
        c.functions.nextGoalId().call()
        return jsonify(ready=True, block=block['number'], timestamp=block['timestamp'])

    @app.get('/api/goals')
    @guarded
    def goals():
        owner = address_arg()
        offset = integer_arg('offset', 0, 0, 2**31 - 1)
        limit = integer_arg('limit', 12, 1, 50)
        c = contract()
        # One snapshot prevents a new block from mixing state within this response.
        block = w3.eth.get_block('latest')
        bn = block['number']
        count = c.functions.goalCount(owner).call(block_identifier=bn)
        result = []
        for index in range(offset, min(count, offset + limit)):
            goal_id = c.functions.goalIdAt(owner, index).call(block_identifier=bn)
            g = c.functions.getGoal(goal_id).call(block_identifier=bn)
            result.append(dict(id=str(goal_id), owner=g[0], unlockAt=g[1], closed=g[2],
                               targetWei=str(g[3]), balanceWei=str(g[4]), name=g[5]))
        return jsonify(goals=result, total=count, nextOffset=offset + limit if offset + limit < count else None,
                       timestamp=block['timestamp'], block=bn)

    @app.get('/api/transactions')
    @guarded
    def transactions():
        owner = address_arg()
        c = contract()
        latest = w3.eth.block_number
        end = integer_arg('before', latest, 0, latest)
        start = max(app.config['DEPLOYMENT_BLOCK'], end - app.config['LOG_BLOCK_RANGE'] + 1)
        result = []
        timestamps = {}
        if start <= end:
            for event_name in ('GoalCreated', 'Deposited', 'Withdrawn'):
                event = getattr(c.events, event_name)
                for log in event.get_logs(from_block=start, to_block=end, argument_filters={'owner': owner}):
                    bn = log['blockNumber']
                    if bn not in timestamps:
                        timestamps[bn] = w3.eth.get_block(bn)['timestamp']
                    args = log['args']
                    result.append(dict(kind=event_name, goalId=str(args['goalId']),
                                       amountWei=str(args.get('amount', 0)), hash=Web3.to_hex(log['transactionHash']),
                                       block=bn, logIndex=log['logIndex'], timestamp=timestamps[bn],
                                       confirmations=latest - bn + 1))
        result.sort(key=lambda item: (item['block'], item['logIndex']), reverse=True)
        return jsonify(transactions=result, fromBlock=start, toBlock=end,
                       nextBefore=start - 1 if start > app.config['DEPLOYMENT_BLOCK'] else None)

    @app.get('/deploy')
    def deploy_page():
        if not app.config['ENABLE_DEPLOY_UI']:
            return 'Deployment helper disabled. See DEPLOYMENT.md.', 404
        return render_template('deploy.html')

    @app.get('/api/deployment-artifact')
    def artifact():
        if not app.config['ENABLE_DEPLOY_UI']:
            return jsonify(error='disabled'), 404
        return jsonify(json.loads((BASE / 'artifacts/StudyFund.json').read_text(encoding='utf-8')))

    return app


app = create_app()
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=int(os.getenv('PORT', '5000')), debug=False)
