# StudyFund

A financial DApp for personal, time-locked learning savings. Built with Solidity, Flask, HTML, CSS and JavaScript. MetaMask signs transactions; the backend only reads the blockchain.

## Delivery status

- Contract compiled with Solidity **0.8.30**, optimizer 200 runs, Paris EVM target.
- **39 contract/backend checks** and **14 browser checks** passed on a local Ethereum test chain. Evidence is in `tests/` and `screenshots/`.
- **Render is live:** https://studyfund-dapp.onrender.com. Public source repository: https://github.com/lyricleo99-cell/studyfund-dapp. The deployed site and health check were verified on 13 October 2026.
- Sepolia contract deployment and real MetaMask verification remain pending wallet signing. The live page explicitly disables savings writes until the contract and RPC are configured.
- The included PDF is seven pages and explicitly describes this verification boundary. Its deployment status records the live web service and the remaining wallet-dependent steps.

## Features and business rules

Connect a wallet; create a goal; deposit test ETH; withdraw the full balance after the unlock time; inspect transaction progress and history. Each goal has an independent balance and one owner. Only that owner may deposit or withdraw. Reaching the target does not release the time lock. A matured goal may be withdrawn even below target. Withdrawal closes the goal permanently. Deposits above target and deposits after maturity are allowed until closure. There is no interest, token, fee collector, administrator or early-withdrawal override.

Goal names are public. Avoid personal information. Use Sepolia test ETH only.

## Run the application

Requirements: Python 3.11, MetaMask browser extension and a Sepolia HTTP RPC endpoint. Node.js 20 or 22 is recommended for recompiling and local tests; Node is not needed by the deployed Flask application.

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env`, then run:

```powershell
python app.py
```

Open `http://127.0.0.1:5000`. With no deployment configured, the page displays a setup notice and disables writes. It does not invent balances or transactions. On macOS/Linux, activate with `source .venv/bin/activate` and copy using `cp .env.example .env`.

See [DEPLOYMENT.md](DEPLOYMENT.md) for wallet-based deployment and Render steps. Never add a wallet private key or recovery phrase to this project.

## Recompile the contract

Precompiled ABI/bytecode and a local ethers browser bundle are included. To reproduce them:

```text
npm ci
npm run compile
```

The compiler exports `abi/StudyFund.json` as a raw ABI array and `artifacts/StudyFund.json` with ABI, deployment bytecode, runtime bytecode and compiler settings. The script also copies ethers and its MIT license into `static/vendor/`. Recompile whenever the Solidity source changes; redeploy and update the address afterward.

## Automated tests

```text
pip install -r requirements-dev.txt
npm ci
python -m pytest tests -q --junitxml=tests/results.xml
```

The test suite starts its own temporary Ganache node on **127.0.0.1:18546**, deploys a fresh contract per test, and stops the node. No external RPC, private keys or testnet ETH are required. Port 18546 must be free. Ganache is a development-only tool with legacy transitive dependencies; it is not installed on Render or exposed publicly.

### Browser integration checks

In terminal 1:

```text
npm run chain
```

In terminal 2 (with the Python environment active):

```text
python scripts/local_preview.py
```

In terminal 3:

```text
npx playwright install chromium
npm run test:browser
```

Alternatively, set `BROWSER_PATH` to an installed Chrome executable. The browser suite uses an isolated temporary browser and an injected EIP-1193 test wallet connected to Ganache. It sends actual local EVM transactions but **does not test the MetaMask extension**. It saves seven screenshots and `tests/browser-results.json`. Restart `scripts/local_preview.py` before rerunning: it deploys a new seeded contract with three goals. The local preview is on port 5001; the normal app uses port 5000.

## Project map

| File/directory | Purpose |
|---|---|
| `contracts/StudyFund.sol` | Auditable savings rules and events |
| `abi/StudyFund.json` | Compiler-generated ABI required by the assignment |
| `artifacts/StudyFund.json` | Reproducible compiled deployment artifact |
| `app.py` | Flask pages and read-only blockchain API |
| `templates/`, `static/css/`, `static/js/` | Responsive interface, wallet and transaction flow |
| `scripts/compile.cjs` | Compile and bundle local browser dependency |
| `render.yaml` | Render deployment blueprint |
| `tests/` | Security, integration tests and measured results |
| `screenshots/` | Actual local browser test evidence |
| `report/` | Seven-page PDF and editable report text |

## API

| Route | Purpose |
|---|---|
| `GET /health` | Server liveness; does not claim RPC readiness |
| `GET /api/config` | Public chain ID, address, ABI and explorer URL; excludes RPC secret |
| `GET /api/status` | Checks network, deployed code and contract response |
| `GET /api/goals?address=0x...&offset=0&limit=12` | Paged owner goals; 1-50 per page; amounts are decimal Wei strings |
| `GET /api/transactions?address=0x...&before=BLOCK` | Owner-filtered event history and backward block cursor |
| `GET /deploy` | Optional local browser deployment helper, disabled by default |

The frontend scans one configured block range at a time and exposes **Scan older blocks**. A blank recent range does not mean the account has no history. Goals load 12 at a time; summary totals refer to loaded goals. Successful events are read from chain; pending hashes are stored only in the browser. Failed or cancelled-before-submission transactions do not emit contract events. Browser-pending transactions are reconciled when reconnecting/reloading on the correct chain. Wallet replacements not observed before a page closes may require checking the original hash in the explorer and clearing stale site storage.

## Security and limits

The smart contract checks ownership, positive amounts, name byte length and unlock bounds, and combines a reentrancy lock with checks-effects-interactions. A failed recipient call reverts closure and balance changes. Inputs are also validated in the UI and API. Untrusted goal names are rendered with `textContent`; JavaScript and ethers are served locally under a same-origin content policy.

There are no session-authenticated write endpoints. Reading an address is public, not proof of identity; on-chain authorization is `msg.sender`. RPC reliability still affects availability. One confirmation is inclusion, not finality. `block.timestamp` is appropriate for coarse savings dates, not precise alarms. Losing wallet access can make funds inaccessible; there is no account recovery. Forced ETH transfers may create unaccounted surplus, which cannot be taken from other users' recorded balances. No independent audit, production load test or real-user usability study has been performed.

## References

- [Solidity security considerations](https://docs.soliditylang.org/en/latest/security-considerations.html)
- [ethers v6 documentation](https://docs.ethers.org/v6/single-page/)
- [Flask deployment with Gunicorn](https://flask.palletsprojects.com/en/stable/deploying/gunicorn/)
- [Render Flask deployment](https://render.com/docs/deploy-flask)

Third-party ethers code retains its license in `static/vendor/ETHERS-LICENSE.md`. The application and contract source are provided for this coursework; understand the implementation and follow your institution's rules for acknowledging assistance.
