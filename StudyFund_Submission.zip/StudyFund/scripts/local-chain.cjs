// Development only: ephemeral, unlocked accounts. Never expose this server publicly.
const ganache = require('ganache');
const port = Number(process.env.TEST_RPC_PORT || 18545);
const server = ganache.server({logging:{quiet:true},chain:{chainId:1337,hardfork:'shanghai'},wallet:{totalAccounts:4,defaultBalance:1000}});
server.listen(port,'127.0.0.1').then(()=>console.log(`Local test chain ready on http://127.0.0.1:${port}`));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close().then(()=>process.exit(0)));
