"""Local QA only: deploy and seed a real ephemeral chain, then serve Flask.

Run npm run chain first. This script never connects to Sepolia or uses private keys.
"""
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import create_app
from web3 import Web3

w3=Web3(Web3.HTTPProvider('http://127.0.0.1:18545'))
assert w3.eth.chain_id==1337, 'Only the local test chain is supported'
artifact=json.loads((ROOT/'artifacts/StudyFund.json').read_text())
owner=w3.eth.accounts[0]
factory=w3.eth.contract(abi=artifact['abi'],bytecode=artifact['bytecode'])
receipt=w3.eth.wait_for_transaction_receipt(factory.constructor().transact({'from':owner}))
fund=w3.eth.contract(address=receipt.contractAddress,abi=artifact['abi'])
gas={'deployment':receipt.gasUsed}
now=w3.eth.get_block('latest').timestamp
for i,(name,target,amount,delay) in enumerate([
    ('Professional certification','0.08','0.052',30*86400),
    ('A semester of textbooks','0.05','0.018',60*86400),
    ('Design course','0.03','0.025',60),
]):
    r=w3.eth.wait_for_transaction_receipt(fund.functions.createGoal(name,w3.to_wei(target,'ether'),now+delay).transact({'from':owner}))
    gas.setdefault('createGoal',r.gasUsed)
    r=w3.eth.wait_for_transaction_receipt(fund.functions.deposit(i).transact({'from':owner,'value':w3.to_wei(amount,'ether')}))
    gas.setdefault('deposit',r.gasUsed)
w3.provider.make_request('evm_increaseTime',[61]);w3.provider.make_request('evm_mine',[])
(ROOT/'tests/gas-results.json').write_text(json.dumps({'network':'Local Ganache chain 1337','compiler':artifact['compiler'],'optimizerRuns':200,'gasUsed':gas},indent=2))
app=create_app({'CONTRACT_ADDRESS':fund.address,'CHAIN_ID':1337,'DEPLOYMENT_BLOCK':receipt.blockNumber,'ENABLE_DEPLOY_UI':True},w3)
print('Local QA preview: http://127.0.0.1:5001',flush=True)
app.run(host='127.0.0.1',port=5001,debug=False)
