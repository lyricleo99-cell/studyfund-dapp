"""Render the editable report Markdown to a seven-page PDF.
Install reportlab and Pillow; run from any directory. No blockchain access needed.
"""
import re
from html import escape
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from PIL import Image as PILImage
import io

ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'report'
INK=colors.HexColor('#173f33');MUTED=colors.HexColor('#6d7b6f');LINE=colors.HexColor('#dae2d3')
styles={
 'body':ParagraphStyle('body',fontName='Helvetica',fontSize=9.2,leading=13.1,textColor=INK,spaceAfter=8),
 'h1':ParagraphStyle('h1',fontName='Helvetica-Bold',fontSize=37,leading=42,textColor=INK,spaceAfter=12),
 'h2':ParagraphStyle('h2',fontName='Helvetica-Bold',fontSize=17,leading=21,textColor=INK,spaceBefore=5,spaceAfter=12),
 'h3':ParagraphStyle('h3',fontName='Helvetica-Bold',fontSize=11,leading=15,textColor=INK,spaceBefore=8,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='Helvetica',fontSize=8,leading=11,textColor=MUTED,spaceAfter=8),
 'cell':ParagraphStyle('cell',fontName='Helvetica',fontSize=8.1,leading=11,textColor=INK),
 'thead':ParagraphStyle('thead',fontName='Helvetica-Bold',fontSize=8.1,leading=11,textColor=colors.white),
}
def inline(text):
    text=escape(text).replace('→',' &gt; ')
    text=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',text)
    text=re.sub(r'`([^`]+)`',r'<font name="Courier" size="8">\1</font>',text)
    text=re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)',r'<i>\1</i>',text)
    return text

def footer(canvas,doc):
    w,h=A4;canvas.setStrokeColor(LINE);canvas.line(44,h-35,w-44,h-35)
    canvas.setFillColor(MUTED);canvas.setFont('Helvetica',8)
    canvas.drawString(44,h-25,'STUDYFUND  /  FINANCIAL DAPP')
    canvas.drawRightString(w-44,h-25,'IMPLEMENTATION & EVALUATION')
    canvas.line(44,37,w-44,37);canvas.drawString(44,24,'Local verification complete · Public deployment pending')
    canvas.drawRightString(w-44,24,f'{doc.page} / 7')

def make_table(lines):
    rows=[]
    for line in lines:
        cells=[x.strip() for x in line.strip('|').split('|')]
        if all(re.fullmatch(r'[-: ]+',x) for x in cells):continue
        style=styles['thead'] if not rows else styles['cell']
        rows.append([Paragraph(inline(x),style) for x in cells])
    count=len(rows[0]);width=A4[0]-88
    widths=[width*.28,width*.46,width*.26] if count==3 else [width*.51,width*.49]
    table=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f0f4e9'),colors.HexColor('#fafbf7')]),('LINEBELOW',(0,0),(-1,-1),.4,LINE)]))
    return table

def screenshot(line):
    filename=re.search(r'\]\((.*?)\)',line).group(1)
    im=PILImage.open(REPORT/filename)
    # Crop to the relevant dashboard, retain originals in screenshots/.
    if '05-' in filename:im=im.crop((260,90,1410,590))
    else:im=im.crop((238,90,1440,950))
    buf=io.BytesIO();im.save(buf,format='PNG');buf.seek(0)
    width=A4[0]-88;height=width*im.height/im.width
    maxh=240 if '02-' in filename else 125
    if height>maxh:width*=maxh/height;height=maxh
    return Image(buf,width=width,height=height,hAlign='CENTER')

def build():
    text=(REPORT/'StudyFund_Report.md').read_text(encoding='utf-8')
    story=[]
    for pi,part in enumerate(text.split('<!-- PAGE -->')):
        if pi:story.append(PageBreak())
        lines=part.strip().splitlines();i=0
        while i<len(lines):
            line=lines[i].strip()
            if not line:i+=1;continue
            if line.startswith('|'):
                table=[]
                while i<len(lines) and lines[i].strip().startswith('|'):table.append(lines[i].strip());i+=1
                story.extend([make_table(table),Spacer(1,10)]);continue
            if line.startswith('!['):story.extend([screenshot(line),Spacer(1,8)]);i+=1;continue
            match=re.match(r'^(#{1,3}) (.*)',line)
            if match:story.append(Paragraph(inline(match.group(2)),styles['h'+str(len(match.group(1)))]));i+=1;continue
            if line.startswith('- '):story.append(Paragraph('• '+inline(line[2:]),styles['body']));i+=1;continue
            paragraph=[line];i+=1
            while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','- ','![')):
                paragraph.append(lines[i].strip());i+=1
            style=styles['small'] if line.startswith(('*Figure','[1]','[2]','[3]','[4]','Documentation consulted')) else styles['body']
            story.append(Paragraph(inline(' '.join(paragraph)),style))
    doc=SimpleDocTemplate(str(REPORT/'StudyFund_Report.pdf'),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=51,bottomMargin=49,title='StudyFund - Financial DApp Report',author='StudyFund coursework project')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print(REPORT/'StudyFund_Report.pdf')

if __name__=='__main__':build()
