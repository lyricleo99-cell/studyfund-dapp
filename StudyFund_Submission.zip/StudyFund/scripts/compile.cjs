const fs = require('fs');
const path = require('path');
const solc = require('solc');
const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'contracts/StudyFund.sol'), 'utf8');
const input = {language: 'Solidity', sources: {'StudyFund.sol': {content: source}}, settings: {
  optimizer: {enabled: true, runs: 200}, evmVersion: 'paris',
  outputSelection: {'*': {'*': ['abi', 'evm.bytecode.object', 'evm.deployedBytecode.object']}}
}};
const output = JSON.parse(solc.compile(JSON.stringify(input)));
for (const error of output.errors || []) console.error(error.formattedMessage);
if ((output.errors || []).some(e => e.severity === 'error')) process.exit(1);
const c = output.contracts['StudyFund.sol'].StudyFund;
for (const dir of ['abi', 'artifacts', 'static/vendor']) fs.mkdirSync(path.join(root, dir), {recursive: true});
fs.writeFileSync(path.join(root, 'abi/StudyFund.json'), JSON.stringify(c.abi, null, 2));
fs.writeFileSync(path.join(root, 'artifacts/StudyFund.json'), JSON.stringify({
  contractName: 'StudyFund', compiler: solc.version(), evmVersion: 'paris', optimizerRuns: 200,
  abi: c.abi, bytecode: '0x' + c.evm.bytecode.object, deployedBytecode: '0x' + c.evm.deployedBytecode.object
}, null, 2));
const ethersRoot = path.resolve(path.dirname(require.resolve('ethers')), '..');
fs.copyFileSync(path.join(ethersRoot, 'dist/ethers.umd.min.js'), path.join(root, 'static/vendor/ethers.umd.min.js'));
fs.copyFileSync(path.join(ethersRoot, 'LICENSE.md'), path.join(root, 'static/vendor/ETHERS-LICENSE.md'));
console.log(`Compiled StudyFund with ${solc.version()}; ABI, bytecode and local ethers bundle written.`);
