# StudyFund
## A time-locked savings DApp for learning goals

**Individual Assignment: Financial Decentralized Application**

Solidity · Ethereum · MetaMask · Flask · HTML / CSS / JavaScript

### 1. Introduction

StudyFund is a financial decentralized application that helps a student reserve funds for a learning goal. A user creates a named goal, sets a target in test ETH and chooses an unlock time. Deposits are held in an Ethereum smart contract and can be withdrawn only by the goal owner after that time. This connects a familiar savings task to verifiable blockchain rules without introducing lending, speculation or promised returns.

A blockchain maintains a shared record of transactions, and a smart contract applies deterministic rules to state changes. In this application, the browser supplies the interface, MetaMask authorizes writes, and Flask reads contract state and events. The funds are governed by the deployed contract rather than by the Flask operator. The web host and RPC provider still influence access and availability; decentralization of custody does not remove those dependencies.

### 2. Problem statement

Students often save for textbooks, a course or an examination, but ordinary budget trackers merely display intentions. They do not enforce a commitment or provide independently inspectable deposit and withdrawal rules. Conversely, generic blockchain interfaces expose hashes and balances without organizing them around an understandable personal objective.

StudyFund combines a goal-oriented interface with a time commitment. For example, a student can reserve 0.05 test ETH for textbooks until a chosen date. Reaching that amount early does not release the time lock. At maturity the student may withdraw even if the target was missed. This separates an aspirational target from the enforceable withdrawal condition.

### 3. Objectives and scope

- Implement wallet-authorized creation, deposits and full-balance withdrawals.
- Enforce ownership, independent goal balances and time locks in Solidity.
- Provide readable progress, error messages and transaction history through a Flask web application.
- Evaluate correctness and security with executable tests, and evaluate interface behavior in desktop and mobile browser views.

**Verification status:** the implementation is complete for local evaluation. The delivered evidence contains 39 passing contract/backend checks and 14 passing browser checks on a local EVM. Actual Sepolia deployment, the real MetaMask extension check and the required Render URL remain pending wallet/account access. The report does not represent these as completed.

<!-- PAGE -->

## 4. System architecture

The system separates transaction authorization from read access. MetaMask sends signed transactions to Ethereum. Flask provides public configuration, pages and read-only data through Web3.py. It does not store private keys, sign on behalf of a user or decide whether a withdrawal is permitted.

| Layer | Responsibility | Boundary |
|---|---|---|
| Browser: HTML, CSS, JavaScript | Goal forms, balances, status and history | Treat input and displayed names as untrusted |
| MetaMask + ethers.js | Account selection and transaction signing | User approves every write |
| Sepolia / StudyFund contract | Ownership, balances, lock and closure | Authoritative financial state |
| Flask + Web3.py + RPC | Read goals, decode events, serve configuration | Availability dependency; no custody |

**Write path:** user form → ethers contract call → MetaMask approval → Ethereum execution → receipt → refreshed Flask data.

**Read path:** browser request → Flask validation → RPC contract call/event query → JSON response → safe DOM rendering.

### 5. Technologies used

| Technology | Version / configuration | Reason for selection |
|---|---|---|
| Solidity | 0.8.30, optimizer 200 runs, Paris EVM | Checked arithmetic and explicit errors |
| Python / Flask | Python 3.11; Flask 3.1.2 | Small, inspectable backend |
| Web3.py | 7.13.0 | Contract reads and event decoding |
| ethers.js | 6.15.0, served locally | BrowserProvider and exact Wei conversion |
| HTML / CSS / JavaScript | Responsive, no UI framework | Direct mapping to assignment files |
| Render / Gunicorn | Prepared deployment configuration | One service serves UI and API |
| Ganache / pytest / Playwright | Local EVM and automated checks | Reproducible isolated evaluation |

### Data and trust model

No database is required. A mapping stores goals, and an owner-to-ID array supports pagination. Events provide a public audit trail. Each goal records its owner, unlock timestamp, closed flag, target, current balance and name. Amounts cross the API as decimal Wei strings, preserving precision beyond JavaScript's safe integer limit.

Wallet connection is not server authentication. Public read endpoints can inspect an address without proving ownership, which is appropriate because chain data is public. Only a transaction's authenticated sender can mutate its own goals. No sensitive profile data is collected, but public goal names and wallet activity can reveal personal interests.

<!-- PAGE -->

## 6. Smart contract design

`StudyFund.sol` contains three write operations and three public query mechanisms. It has no administrator, token issuance, external yield strategy or upgrade mechanism. The compiler exports an ABI array and deployment/runtime bytecode from the same source, reducing configuration mismatches between frontend and backend.

| Operation | Validation | State change / event |
|---|---|---|
| createGoal(name, target, unlockAt) | 1-64 name bytes, target > 0, future time within 3,650 days | Allocate ID, record owner, emit GoalCreated |
| deposit(id), payable | Existing goal, caller is owner, open goal, value > 0 | Increase only this balance; emit Deposited |
| withdraw(id) | Owner, open goal, timestamp reached, balance > 0 | Zero balance, close, transfer, emit Withdrawn |
| getGoal / goalCount / goalIdAt | Valid goal or array index | Read state without a transaction |

### State transitions

A goal begins open with zero balance. Valid deposits increase its balance. At the unlock timestamp, withdrawal becomes eligible without a separate state-changing transaction. A successful withdrawal returns the full balance and marks the goal closed. The closed goal remains visible for history, and later deposits or withdrawals are rejected. An empty matured goal remains open until funded; deposits after maturity are permitted and immediately eligible for withdrawal.

### Financial invariants

- A caller cannot spend or add to another owner's goal.
- A withdrawal cannot exceed the recorded balance of the selected goal.
- Reaching the target never bypasses the timestamp check.
- Successful withdrawal zeroes the balance and prevents a second withdrawal.
- A failed ETH transfer reverts both balance and closed-state changes.

For ordinary accepted deposits and withdrawals, the sum of goal balances matches ETH held by the contract. Forced ETH transfers can produce surplus without a corresponding goal; the invariant for general Ethereum behavior is that liabilities do not exceed holdings. The contract provides no administrator path to extract that surplus or user balances.

### Defensive execution and gas

Withdrawal follows checks-effects-interactions: it verifies ownership and maturity, updates state, then calls the recipient. A reentrancy lock covers deposit and withdrawal. Reverting on a failed call restores the previous state. These measures follow the threat model described in Solidity's security guidance [1], and adversarial receiver tests exercise both failure and reentry.

Custom errors reduce revert-data overhead; the owner, timestamp and closed flag can share a storage slot. On-chain operations avoid loops over all goals. Pagination happens in read APIs. These choices improve predictable execution but do not constitute a formal gas-optimality proof or an independent security audit.

<!-- PAGE -->

## 7. Application design

The interface uses a quiet green palette, clear savings cards and a consistent action hierarchy. The primary task is to create a goal or add funds. Each card displays the target, balance, progress, date and lock state. The dashboard clearly labels its summary as saved in loaded goals, avoiding an inaccurate whole-account total when pagination is in use.

![Desktop dashboard](../screenshots/02-dashboard-local-chain.png)

*Figure 1. Running desktop interface, backed by local chain 1337. These are test accounts and local transactions, not a Sepolia or Render deployment. Full-resolution evidence is provided separately.*

### Wallet and transaction experience

The app requests wallet access when the user chooses Connect. It checks the network before writes and responds to account and chain changes. A goal form explains that the name is public and requires acknowledgement that early withdrawal is unavailable. Target and deposit amounts use exact decimal-to-Wei conversion; invalid amounts do not open a transaction request.

Transaction messages distinguish waiting for wallet approval, submitted/pending, confirmation, rejection and failure. The app waits for a receipt rather than assuming submission means success [2]. Pending hashes survive a page reload in browser storage and are checked on reconnection. A timeout is described as unresolved, not as a confirmed failure. Explorer links are enabled for Sepolia only.

### Responsive and accessible behavior

The layout adapts from three goal columns to a single column at narrow widths. Form controls have labels; dialogs use native modal behavior; status messages use live regions; important states have text as well as color. Browser checks verified a 390-pixel view without horizontal page overflow. This is functional layout evaluation, not a measured accessibility certification or a participant-based usability study.

<!-- PAGE -->

## 8. Implementation and backend integration

Flask serves both templates and JSON endpoints, simplifying deployment to one origin. `/api/config` returns public chain metadata and ABI while withholding the server's RPC URL. `/api/status` checks chain ID, deployed code and a contract read. `/health` only reports server liveness, so a healthy Render process is not confused with a working blockchain connection.

The goals endpoint validates addresses and page bounds, then reads one consistent block snapshot. The history endpoint filters indexed owner fields and scans a bounded range of blocks, returning a cursor for older ranges. The UI exposes that cursor as Scan older blocks. Its history consists of contract events; failed transactions do not produce those events. HTTP errors use stable messages and do not expose credential-bearing RPC exceptions.

### 9. Testing and results

All tests used the compiled project contract. Pytest launched an isolated Ganache chain on loopback, and browser checks used a separate local chain plus an injected EIP-1193 wallet. The latter performs actual local transactions while emulating wallet approval/rejection; it does not automate the MetaMask extension.

| Evaluation area | Executed checks / evidence | Result |
|---|---|---|
| Smart contract | 21 parameterized checks: validation, authorization, accounting, maturity, closure, recipient failure, reentrancy | 21 passed |
| Flask and API | 18 checks: paging, owner filtering, configuration, readiness, headers, error secrecy | 18 passed |
| Browser workflow | 14 checks: connect, create, deposit, withdraw, reject, network/account changes, reload, mobile | 14 passed |
| Source compilation | Solidity 0.8.30; ABI and bytecode generated | Passed |
| Sepolia / MetaMask / Render | Real-wallet smoke test and public deployment | Not executed |

### Representative assertions

The withdrawal test checks the owner's ending balance against starting balance plus the withdrawal minus actual gas cost. Another test funds two owners' goals, withdraws one, and confirms the other balance remains unchanged. An attacking receiver tries to call withdrawal recursively; a rejecting receiver verifies that failed payment does not lose the savings or close the goal. These are behavior-based security checks rather than tests that merely inspect source strings.

In browser testing, the initial loaded balance was 0.095 ETH. A 0.001 ETH deposit raised it to 0.096 ETH. Withdrawing a matured 0.025 ETH goal reduced it to 0.071 ETH and closed that goal. The browser also submitted a new goal and observed it in the backend response. Raw results are included in `tests/results.xml` and `tests/browser-results.json`.

<!-- PAGE -->

## 10. Security and performance evaluation

| Concern | Implemented control | Remaining limitation |
|---|---|---|
| Authorization | msg.sender must equal goal owner | Lost wallet access has no recovery |
| Reentrancy / failed transfers | Guard, effects before call, revert on failure | No independent audit |
| Input and precision | Solidity bounds, frontend parsing, Wei strings | Public users can interact directly with the contract |
| Private keys | Browser wallet signs; server only reads | User must secure the wallet and device |
| Injection and data privacy | textContent, local scripts, security headers | Goal names and transactions remain public |
| Availability / finality | RPC errors, paging, receipt status | RPC outages and chain reorganizations remain possible |

### Measured execution cost

| Operation | Gas used in local measurement |
|---|---|
| Contract deployment | 735,957 |
| Create first goal | 142,214 |
| First deposit to a goal | 52,732 |
| Full matured withdrawal | 40,490 |

These measurements came from real local receipts using the optimized contract. Gas cost varies with state and input length. The first named goal was Professional certification; its target was 0.08 ETH and initial deposit was 0.052 ETH. Values are execution units, not a quotation of Sepolia or mainnet fees. No throughput, public-network latency or concurrent-user load benchmark was performed.

### Transaction evidence

![Confirmed withdrawal](../screenshots/05-withdraw-confirmed-local-chain.png)

*Figure 2. Local-chain withdrawal confirmation. The Design course goal closes and the displayed savings total falls to 0.071 ETH. The original screenshot includes the event-history table.*

The UI calls a transaction confirmed after one block inclusion and explicitly states that this is not finality. Event queries are refreshed rather than copied into an unverified database. A production system would need stronger finality handling, monitoring and a durable indexer. This coursework implementation deliberately keeps custody logic small and inspectable.

<!-- PAGE -->

## 11. Challenges encountered

Two common integration risks were exact ETH arithmetic and asynchronous state. Decimal amounts are parsed to integer Wei rather than JavaScript floating point. After a receipt, the interface refreshes data from Flask; browser assertions wait for the new balance instead of reading before the refresh completes. A generation counter prevents a slow response for an old account from replacing the newly selected account's data.

The initial Python EVM-emulator dependency required a native compiler on the Windows environment. Local testing was moved to a separate Ganache process, keeping deployment dependencies smaller. The browser tests use an isolated wallet adapter because a real MetaMask session and account authorization were not provided. That difference is preserved in the evidence rather than hidden.

## 12. Limitations and future improvements

The project supports native test ETH only, with no yield, fiat conversion, partial withdrawal or emergency override. Time locking creates deliberate inflexibility, and goal metadata is public. Large event histories require repeated bounded scans. Public production hosting would also need rate limits, RPC budgeting, monitoring and stronger operational hardening. The local-only test tooling includes legacy dependencies and must not be exposed as a public service.

Possible extensions include encrypted off-chain descriptions, token savings with explicit decimal handling, a reorganization-aware indexer, transaction replacement reconciliation after reload, and an accessibility audit with student participants. Any recovery or early-exit design would require revisiting the trust model rather than silently adding administrator control.

### Deployment and delivery status

The repository includes the Solidity source, ABI, Flask application, HTML/CSS/JavaScript, test evidence, screenshots, README and Render blueprint. Render's Flask workflow uses a Python web service and Gunicorn [3,4]. The supplied deployment helper asks MetaMask to deploy the compiled contract directly; no private key is entered into Flask.

**Outstanding:** authorize Sepolia deployment, save its actual address/block/hash, run the real-wallet smoke test, deploy through the user's Render account, and record the real HTTPS URL. Those steps require user-controlled wallet and account access. The delivered local address is not a substitute for the required Render link.

## 13. Conclusion

StudyFund demonstrates blockchain state, Solidity authorization, browser wallet integration and a read-only Flask backend in one focused financial application. Local tests support its core savings behavior and defensive controls. Completing the public deployment and real-wallet evidence is necessary before claiming that every submission requirement has been fulfilled.

### References

[1] Solidity. Security Considerations. https://docs.soliditylang.org/en/latest/security-considerations.html

[2] ethers. Version 6 documentation. https://docs.ethers.org/v6/single-page/

[3] Render. Deploy a Flask App. https://render.com/docs/deploy-flask

[4] Flask. Gunicorn deployment. https://flask.palletsprojects.com/en/stable/deploying/gunicorn/

Documentation consulted 13 October 2026. Local result files and screenshots are the primary evidence for this report.
