// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

/// @title StudyFund - personal, time-locked learning savings (testnet coursework)
/// @notice Target amounts track progress; only time controls withdrawal.
contract StudyFund {
    struct Goal {
        address owner;
        uint64 unlockAt;
        bool closed;
        uint256 target;
        uint256 balance;
        string name;
    }
    uint256 public nextGoalId;
    mapping(uint256 => Goal) private goals;
    mapping(address => uint256[]) private ownerGoals;
    uint256 private entered = 1;

    error InvalidName();
    error InvalidAmount();
    error InvalidUnlockTime();
    error GoalNotFound();
    error NotOwner();
    error GoalClosed();
    error StillLocked();
    error EmptyBalance();
    error TransferFailed();
    error Reentrancy();

    event GoalCreated(uint256 indexed goalId, address indexed owner, string name, uint256 target, uint64 unlockAt);
    event Deposited(uint256 indexed goalId, address indexed owner, uint256 amount, uint256 balance);
    event Withdrawn(uint256 indexed goalId, address indexed owner, uint256 amount);

    modifier nonReentrant() {
        if (entered != 1) revert Reentrancy();
        entered = 2;
        _;
        entered = 1;
    }

    function createGoal(string calldata name, uint256 target, uint64 unlockAt) external returns (uint256 id) {
        if (bytes(name).length == 0 || bytes(name).length > 64) revert InvalidName();
        if (target == 0) revert InvalidAmount();
        if (unlockAt <= block.timestamp || unlockAt > block.timestamp + 3650 days) revert InvalidUnlockTime();
        id = nextGoalId++;
        goals[id] = Goal(msg.sender, unlockAt, false, target, 0, name);
        ownerGoals[msg.sender].push(id);
        emit GoalCreated(id, msg.sender, name, target, unlockAt);
    }

    function deposit(uint256 id) external payable nonReentrant {
        Goal storage goal = ownedGoal(id);
        if (goal.closed) revert GoalClosed();
        if (msg.value == 0) revert InvalidAmount();
        goal.balance += msg.value;
        emit Deposited(id, msg.sender, msg.value, goal.balance);
    }

    function withdraw(uint256 id) external nonReentrant {
        Goal storage goal = ownedGoal(id);
        if (goal.closed) revert GoalClosed();
        if (block.timestamp < goal.unlockAt) revert StillLocked();
        uint256 amount = goal.balance;
        if (amount == 0) revert EmptyBalance();
        // Effects precede interaction. A failed transfer rolls all effects back.
        goal.balance = 0;
        goal.closed = true;
        (bool success, ) = payable(msg.sender).call{value: amount}("");
        if (!success) revert TransferFailed();
        emit Withdrawn(id, msg.sender, amount);
    }

    function getGoal(uint256 id) external view returns (Goal memory) {
        if (id >= nextGoalId) revert GoalNotFound();
        return goals[id];
    }
    function goalCount(address owner) external view returns (uint256) { return ownerGoals[owner].length; }
    function goalIdAt(address owner, uint256 index) external view returns (uint256) { return ownerGoals[owner][index]; }

    function ownedGoal(uint256 id) private view returns (Goal storage goal) {
        if (id >= nextGoalId) revert GoalNotFound();
        goal = goals[id];
        if (goal.owner != msg.sender) revert NotOwner();
    }
    // No payable receive/fallback: ordinary accidental transfers are rejected.
}
