# Screenshot provenance

All seven PNGs were captured from the running Flask application by `tests/browser.cjs`. The chain was a real local Ganache EVM (chain ID 1337), using an injected EIP-1193 wallet adapter in an isolated headless Chromium browser. These are **not Sepolia, Render or MetaMask extension screenshots**. The network label in the UI identifies the local test network.

1. `01-disconnected-desktop.png`: wallet disconnected.
2. `02-dashboard-local-chain.png`: three goals read from the local contract.
3. `03-wallet-cancelled-local-test.png`: simulated wallet rejection, correctly reported by the app.
4. `04-deposit-confirmed-local-chain.png`: actual local-chain deposit and updated balance.
5. `05-withdraw-confirmed-local-chain.png`: actual matured withdrawal and closed goal.
6. `06-create-goal-form.png`: goal input and time-lock acknowledgement.
7. `07-mobile-local-chain.png`: 390 px responsive layout.

Browser transaction hashes are valid only for that temporary local chain. Record new screenshots and transaction hashes after deploying to Sepolia.
