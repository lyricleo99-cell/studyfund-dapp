/* global ethers */
'use strict';
const button=document.getElementById('deploy'),output=document.getElementById('result');
button.onclick=async()=>{button.disabled=true;try{
 if(!window.ethereum)throw new Error('Install MetaMask in this browser first.');
 await window.ethereum.request({method:'eth_requestAccounts'});
 await window.ethereum.request({method:'wallet_switchEthereumChain',params:[{chainId:'0xaa36a7'}]});
 const provider=new ethers.BrowserProvider(window.ethereum);
 if((await provider.getNetwork()).chainId!==11155111n)throw new Error('Sepolia is required.');
 const response=await fetch('/api/deployment-artifact');if(!response.ok)throw new Error('Deployment helper is disabled.');
 const artifact=await response.json();const factory=new ethers.ContractFactory(artifact.abi,artifact.bytecode,await provider.getSigner());
 output.textContent='Review the contract deployment in MetaMask…';const contract=await factory.deploy();
 output.textContent='Deployment submitted: '+contract.deploymentTransaction().hash+'\nWaiting for confirmation…';
 const receipt=await contract.deploymentTransaction().wait();
 output.textContent='CONTRACT_ADDRESS='+await contract.getAddress()+'\nDEPLOYMENT_BLOCK='+receipt.blockNumber+'\nCHAIN_ID=11155111\n\nTransaction: '+receipt.hash+'\n\nSet RPC_URL separately. Restart Flask after saving. Disable ENABLE_DEPLOY_UI on Render.';
}catch(e){output.textContent=e.shortMessage||e.message;button.disabled=false;}};
