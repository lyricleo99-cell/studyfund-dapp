/* global ethers */
'use strict';
const $ = id => document.getElementById(id);
const S = {config:null, account:null, provider:null, chain:null, goals:[], history:[], nextOffset:null, nextBefore:null, timestamp:0, busy:false, generation:0, selected:null};
const eth = wei => ethers.formatEther(BigInt(wei));
const short = text => text.slice(0,6)+'…'+text.slice(-4);
const date = ts => new Date(Number(ts)*1000).toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'});
function node(tag, text, cls) { const n=document.createElement(tag); if(text!==undefined)n.textContent=text; if(cls)n.className=cls; return n; }
function feedback(message, error=false, hash=null) {
  const box=$('feedback'); box.replaceChildren(document.createTextNode(message)); box.className='feedback'+(error?' error':''); box.hidden=false;
  document.querySelectorAll('.dialog-feedback').forEach(n=>n.remove());
  const open=document.querySelector('dialog[open]');
  if(open){const local=node('p',message,'dialog-feedback feedback'+(error?' error':''));local.setAttribute('role','alert');open.append(local);}
  if(hash && S.config?.explorer){const link=node('a','View transaction ↗');link.href=S.config.explorer+'/tx/'+hash;link.target='_blank';link.rel='noopener noreferrer';box.append(link);}
}
async function api(path){const r=await fetch(path);const body=await r.json();if(!r.ok)throw new Error(body.message||'The server is unavailable.');return body;}
function validAmount(text){if(!/^(?:0|[1-9]\d*)(?:\.\d{1,18})?$/.test(text.trim()))throw new Error('Enter a positive ETH amount with up to 18 decimal places.');const value=ethers.parseEther(text.trim());if(value<=0n || value>ethers.MaxUint256)throw new Error('The amount is outside the supported range.');return value;}
function writable(){return !!(S.account && S.config?.configured && S.chain===BigInt(S.config.chainId) && !S.busy);}
function controls(){ $('new-goal').disabled=!writable();$('refresh').disabled=!S.account || S.busy;$('connect').disabled=S.busy;document.querySelectorAll('.goal-actions button,dialog button[type="submit"]').forEach(b=>b.disabled=!writable()||b.dataset.unavailable==='true'); }
function pendingKey(){return `studyfund:${S.config.chainId}:${S.config.contractAddress.toLowerCase()}:${S.account?.toLowerCase()}`;}
function readPending(){try{return JSON.parse(localStorage.getItem(pendingKey())||'[]');}catch{return [];}}
function savePending(items){try{localStorage.setItem(pendingKey(),JSON.stringify(items));}catch{/* Wallet receipt tracking still works without local storage. */}}
function errorText(e){
  if(e.code===4001||e.code==='ACTION_REJECTED')return 'You cancelled the wallet request. No new transaction was submitted.';
  if(e.code==='INSUFFICIENT_FUNDS')return 'Not enough test ETH. Leave enough in your wallet to pay gas.';
  const name=e.revert?.name||e.reason||'';
  const messages={StillLocked:'This goal is still locked.',NotOwner:'Only the goal owner can do this.',GoalClosed:'This goal has already been closed.',EmptyBalance:'This goal has no funds to withdraw.',InvalidUnlockTime:'Choose an unlock time in the future, within 10 years.'};
  return messages[name]||e.shortMessage||e.message||'The request failed. Please try again.';
}
function renderGoals(){
  const grid=$('goals-grid');grid.replaceChildren();let total=0n,available=0n,active=0;
  for(const g of S.goals){
    const balance=BigInt(g.balanceWei),ready=!g.closed&&g.unlockAt<=S.timestamp;total+=balance;if(ready)available+=balance;if(!g.closed)active++;
    const card=node('article',undefined,'goal-card');const top=node('div',undefined,'goal-top');top.append(node('span','◎','goal-icon'),node('span',g.closed?'Completed':ready?'Unlocked':'Time locked','badge'+(ready?' ready':'')));
    card.append(top,node('h3',g.name),node('p',(g.closed?'Closed goal · ':ready?'Unlocked · ':'Unlocks · ')+date(g.unlockAt),'goal-date'));
    const amount=node('div',undefined,'goal-amount');amount.append(node('strong',eth(balance)),node('span','/ '+eth(g.targetWei)+' ETH'));card.append(amount);
    const bps=balance*10000n/BigInt(g.targetWei);const progress=node('progress',undefined,'progress');progress.max=10000;progress.value=Number(bps>10000n?10000n:bps);progress.setAttribute('aria-label','Savings progress');card.append(progress);
    const meta=node('div',undefined,'progress-meta');meta.append(node('span',`${bps/100n}.${(bps%100n).toString().padStart(2,'0')}% saved`),node('span','Goal #'+g.id));card.append(meta);
    const actions=node('div',undefined,'goal-actions');const add=node('button','＋ Add funds','button button-outline');add.dataset.unavailable=String(g.closed);add.onclick=()=>{S.selected=g;$('deposit-title').textContent='Save for '+g.name;$('deposit-form').reset();$('deposit-dialog').showModal();};const withdraw=node('button',g.closed?'Completed':ready?'Withdraw ↗':'Locked','button button-outline');withdraw.dataset.unavailable=String(g.closed||!ready||balance===0n);withdraw.onclick=()=>{S.selected=g;$('withdraw-description').textContent=`Withdraw ${eth(g.balanceWei)} ETH from “${g.name}” to your connected wallet.`;$('withdraw-dialog').showModal();};actions.append(add,withdraw);card.append(actions);grid.append(card);
  }
  if(!S.goals.length){const empty=node('div',undefined,'empty-state');empty.append(node('span','◎','empty-icon'),node('h3',S.account?'What will you learn next?':'Start with something worth learning.'),node('p',S.account?'Create your first goal using the button above.':'Connect your wallet to view your savings goals.'));grid.append(empty);}
  $('total-saved').textContent=S.account?eth(total):'—';$('available').textContent=S.account?eth(available):'—';$('active-goals').textContent=S.account?active:'—';$('goals-count').textContent=S.goals.length;$('more-goals').hidden=S.nextOffset===null;controls();
}
function renderHistory(){
  const body=$('history');body.replaceChildren();
  for(const p of readPending()){const tr=node('tr');tr.append(node('td',p.label),node('td','—'),node('td','—'),node('td',date(p.timestamp)),node('td','Pending · '+short(p.hash)));body.append(tr);}
  for(const item of S.history){const tr=node('tr');const title={GoalCreated:'◎ Goal created',Deposited:'↓ Deposit',Withdrawn:'↗ Withdrawal'}[item.kind];tr.append(node('td',title),node('td','#'+item.goalId),node('td',item.kind==='GoalCreated'?'—':eth(item.amountWei)+' ETH'),node('td',date(item.timestamp)));const cell=node('td');const label=`Confirmed (${item.confirmations}) · ${short(item.hash)}`;if(S.config.explorer){const a=node('a',label);a.href=S.config.explorer+'/tx/'+item.hash;a.target='_blank';a.rel='noopener noreferrer';cell.append(a);}else cell.textContent=label;tr.append(cell);body.append(tr);}
  if(!body.children.length){const tr=node('tr'),td=node('td','No events in this block range. Scan older blocks if your goal was created earlier.','table-empty');td.colSpan=5;tr.append(td);body.append(tr);}
  $('more-history').hidden=S.nextBefore===null;
}
async function loadGoals(append=false){const gen=S.generation;const offset=append?S.nextOffset:0;const data=await api(`/api/goals?address=${S.account}&offset=${offset}`);if(gen!==S.generation)return;S.goals=append?[...S.goals,...data.goals]:data.goals;S.nextOffset=data.nextOffset;S.timestamp=data.timestamp;$('goal-count-note').textContent=`${S.goals.length} of ${data.total} goals loaded`;renderGoals();}
async function loadHistory(append=false){const gen=S.generation;const data=await api(`/api/transactions?address=${S.account}`+(append?`&before=${S.nextBefore}`:''));if(gen!==S.generation)return;S.history=append?[...S.history,...data.transactions]:data.transactions;S.nextBefore=data.nextBefore;$('history-range').textContent=`Showing events from blocks ${data.fromBlock}–${data.toBlock}. One confirmation is not finality.`;renderHistory();}
async function refresh(){if(!S.account)return;await Promise.all([loadGoals(),loadHistory()]);}
async function reconcilePending(){if(!S.provider||!S.account||S.chain!==BigInt(S.config.chainId))return;const generation=S.generation;const pending=readPending(),remain=[];for(const p of pending){const receipt=await S.provider.getTransactionReceipt(p.hash);if(generation!==S.generation)return;if(!receipt)remain.push(p);else feedback(receipt.status===1?'Previously pending transaction confirmed.':'Previously pending transaction reverted.',receipt.status!==1,p.hash);}if(generation===S.generation)savePending(remain);}
async function connected(accounts){
  S.generation++;S.account=accounts[0]||null;S.goals=[];S.history=[];S.nextOffset=null;S.nextBefore=null;
  if(S.account){S.provider=new ethers.BrowserProvider(window.ethereum);S.chain=BigInt(await window.ethereum.request({method:'eth_chainId'}));$('connect').textContent=short(S.account);if(S.chain!==BigInt(S.config.chainId)){feedback('Wrong network. Click your wallet address to switch to '+(S.config.chainId===11155111?'Sepolia.':'the configured test network.'),true);}}
  else {$('connect').textContent='Connect wallet ↗';S.chain=null;}
  renderGoals();renderHistory();if(S.account&&S.config.configured){await reconcilePending();await refresh();}
}
async function connect(){try{if(!window.ethereum)throw new Error('MetaMask was not found. Install the browser extension, then reload this page.');if(S.account && S.chain!==BigInt(S.config.chainId)){await window.ethereum.request({method:'wallet_switchEthereumChain',params:[{chainId:ethers.toBeHex(S.config.chainId)}]});}await connected(await window.ethereum.request({method:'eth_requestAccounts'}));}catch(e){feedback(errorText(e),true);}}
async function transact(label, action, dialog){
  if(!writable()){feedback('Connect your wallet on the configured network first.',true);return;}
  const account=S.account,chain=S.chain,generation=S.generation,key=pendingKey();let hash=null;
  S.busy=true;controls();feedback('Waiting for your approval in MetaMask…');
  try{
    const signer=await S.provider.getSigner();if((await signer.getAddress()).toLowerCase()!==account.toLowerCase())throw new Error('The wallet account changed. Please retry.');
    if(BigInt(await window.ethereum.request({method:'eth_chainId'}))!==chain)throw new Error('The wallet network changed. Please retry.');
    const contract=new ethers.Contract(S.config.contractAddress,S.config.abi,signer);const tx=await action(contract);hash=tx.hash;
    try{const list=JSON.parse(localStorage.getItem(key)||'[]');list.push({hash,label,timestamp:Math.floor(Date.now()/1000)});localStorage.setItem(key,JSON.stringify(list));}catch{}
    $(dialog).close();feedback('Transaction submitted. Waiting for a block confirmation…',false,hash);renderHistory();
    let receipt;
    try{receipt=await tx.wait(1,120000);}catch(e){if(e.code==='TRANSACTION_REPLACED'&&!e.cancelled){receipt=e.receipt;hash=e.replacement.hash;}else throw e;}
    try{const list=JSON.parse(localStorage.getItem(key)||'[]');localStorage.setItem(key,JSON.stringify(list.filter(p=>p.hash!==tx.hash)));}catch{}
    if(!receipt||receipt.status!==1)throw new Error('The transaction reverted on-chain.');
    feedback(label+' confirmed. The network may still reorganize recent blocks.',false,hash);
    if(generation===S.generation){try{await refresh();}catch{feedback(label+' confirmed, but the dashboard could not refresh. Use Refresh to retry.',false,hash);}}
  }catch(e){
    if(hash && (e.receipt || (e.code==='TRANSACTION_REPLACED'&&e.cancelled))){try{const list=JSON.parse(localStorage.getItem(key)||'[]');localStorage.setItem(key,JSON.stringify(list.filter(p=>p.hash!==hash)));}catch{}feedback(e.cancelled?'Transaction was replaced or cancelled in your wallet.':'Transaction reverted on-chain; gas may still have been charged.',true,hash);}
    else if(hash)feedback('Transaction submitted; confirmation needs checking. '+errorText(e),true,hash);
    else feedback(errorText(e),true);
  }
  finally{S.busy=false;controls();}
}
$('connect').onclick=connect;$('empty-connect').onclick=connect;
$('new-goal').onclick=()=>{$('goal-form').reset();$('goal-dialog').showModal();};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
$('goal-form').onsubmit=e=>{e.preventDefault();try{const name=$('goal-name').value.trim();if(!name||new TextEncoder().encode(name).length>64)throw new Error('Use a name between 1 and 64 UTF-8 bytes.');const target=validAmount($('goal-target').value);const unlock=Math.floor(new Date($('goal-date').value).getTime()/1000);const now=Math.floor(Date.now()/1000);if(!Number.isFinite(unlock)||unlock<now+120||unlock>now+3650*86400)throw new Error('Choose an unlock time at least 2 minutes from now and within 10 years.');transact('Goal created',c=>c.createGoal(name,target,unlock),'goal-dialog');}catch(err){feedback(errorText(err),true);}};
$('deposit-form').onsubmit=e=>{e.preventDefault();try{const value=validAmount($('deposit-amount').value),id=S.selected.id;transact('Deposit',c=>c.deposit(id,{value}),'deposit-dialog');}catch(err){feedback(errorText(err),true);}};
$('withdraw-form').onsubmit=e=>{e.preventDefault();const id=S.selected.id;transact('Withdrawal',c=>c.withdraw(id),'withdraw-dialog');};
$('refresh').onclick=()=>refresh().catch(e=>feedback(errorText(e),true));
$('more-goals').onclick=async()=>{const b=$('more-goals');b.disabled=true;try{await loadGoals(true);}catch(e){feedback(errorText(e),true);}finally{b.disabled=false;}};
$('more-history').onclick=async()=>{const b=$('more-history');b.disabled=true;try{await loadHistory(true);}catch(e){feedback(errorText(e),true);}finally{b.disabled=false;}};
async function init(){try{S.config=await api('/api/config');$('network-label').lastChild.textContent=S.config.chainId===11155111?' Sepolia testnet':' Local test network';if(!S.config.configured){$('setup-banner').textContent='Deployment not configured yet. The interface is ready; set the Sepolia RPC URL and deployed contract address to enable savings.';$('setup-banner').hidden=false;}else{await api('/api/status');if(S.config.explorer){$('contract-link').href=S.config.explorer+'/address/'+S.config.contractAddress;$('contract-link').hidden=false;}}
  if(window.ethereum){window.ethereum.on('accountsChanged',accounts=>connected(accounts).catch(e=>feedback(errorText(e),true)));window.ethereum.on('chainChanged',()=>connected(S.account?[S.account]:[]).catch(e=>feedback(errorText(e),true)));window.ethereum.on('disconnect',()=>connected([]).catch(()=>{}));const accounts=await window.ethereum.request({method:'eth_accounts'});if(accounts.length)await connected(accounts);}
}catch(e){feedback(errorText(e),true);}finally{controls();}}
init();
