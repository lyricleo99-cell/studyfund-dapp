// Isolated browser QA with an EIP-1193 wallet adapter backed by real local EVM transactions.
// This is NOT a MetaMask extension test and never handles a real wallet.
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const evidence=path.join(root,'screenshots');fs.mkdirSync(evidence,{recursive:true});
let rpcId=0;
async function rpc(method,params=[]){const r=await fetch('http://127.0.0.1:18545',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:++rpcId,method,params})});const d=await r.json();if(d.error)throw Error(d.error.message);return d.result;}
(async()=>{
 const options={headless:true};if(process.env.BROWSER_PATH)options.executablePath=process.env.BROWSER_PATH;
 const browser=await chromium.launch(options),context=await browser.newContext({viewport:{width:1440,height:1080}}),page=await context.newPage();
 const errors=[],checks=[];page.on('pageerror',e=>errors.push(e.message));
 const accounts=await rpc('eth_accounts');
 await page.exposeFunction('localRpc',rpc);
 await page.addInitScript(({accounts})=>{
   const handlers={};window.qaWallet={connected:false,index:0,reject:false,chain:'0x539'};
   window.ethereum={isMetaMask:false,on:(name,cb)=>{(handlers[name]??=[]).push(cb);},request:async({method,params=[]})=>{
     if(method==='eth_accounts')return window.qaWallet.connected?[accounts[window.qaWallet.index]]:[];
     if(method==='eth_requestAccounts'){window.qaWallet.connected=true;return [accounts[window.qaWallet.index]];}
     if(method==='eth_chainId')return window.qaWallet.chain;
     if(method==='wallet_switchEthereumChain'){window.qaWallet.chain=params[0].chainId;handlers.chainChanged?.forEach(cb=>cb(window.qaWallet.chain));return null;}
     if(method==='eth_sendTransaction'&&window.qaWallet.reject){window.qaWallet.reject=false;throw Object.assign(new Error('User rejected request'),{code:4001});}
     return window.localRpc(method,params);
   }};
   window.qaWallet.change=(index)=>{window.qaWallet.index=index;handlers.accountsChanged?.forEach(cb=>cb([accounts[index]]));};
   window.qaWallet.network=(chain)=>{window.qaWallet.chain=chain;handlers.chainChanged?.forEach(cb=>cb(chain));};
 },{accounts});
 try{
  await page.goto('http://127.0.0.1:5001');await page.waitForFunction(()=>document.getElementById('connect').disabled===false);
  await page.screenshot({path:path.join(evidence,'01-disconnected-desktop.png'),fullPage:true});
  await page.locator('#connect').click();await page.waitForFunction(()=>document.querySelectorAll('.goal-card').length===3);checks.push('Wallet adapter connects and loads three on-chain goals');
  assert.equal(await page.locator('#total-saved').textContent(),'0.095');checks.push('Exact ETH total read from Flask and local chain');
  await page.screenshot({path:path.join(evidence,'02-dashboard-local-chain.png'),fullPage:true});
  assert.equal(await page.locator('.goal-card').nth(0).getByRole('button',{name:'Locked',exact:true}).isDisabled(),true);checks.push('Early withdrawal disabled in UI');
  await page.locator('.goal-card').nth(0).getByRole('button',{name:'Add funds'}).click();
  await page.locator('#deposit-amount').fill('0');await page.locator('#deposit-form button[type=submit]').click();await page.getByText('The amount is outside the supported range.',{exact:true}).last().waitFor();checks.push('Invalid amount shown inside dialog');
  await page.locator('#deposit-amount').fill('0.001');await page.evaluate(()=>window.qaWallet.reject=true);await page.locator('#deposit-form button[type=submit]').click();await page.waitForFunction(()=>document.querySelector('.dialog-feedback')?.textContent.includes('cancelled'));checks.push('Wallet cancellation reported without success');
  await page.screenshot({path:path.join(evidence,'03-wallet-cancelled-local-test.png'),fullPage:true});
  await page.locator('#deposit-form button[type=submit]').click();await page.waitForFunction(()=>document.getElementById('feedback').textContent.startsWith('Deposit confirmed.'),{},{timeout:30000});
  await page.waitForFunction(()=>document.getElementById('total-saved').textContent==='0.096');checks.push('UI deposit executes a real local-chain transaction');
  await page.screenshot({path:path.join(evidence,'04-deposit-confirmed-local-chain.png'),fullPage:true});
  await page.locator('.goal-card').nth(2).getByRole('button',{name:'Withdraw'}).click();await page.locator('#withdraw-form button[type=submit]').click();
  await page.waitForFunction(()=>document.getElementById('feedback').textContent.startsWith('Withdrawal confirmed.'),{},{timeout:30000});
  await page.waitForFunction(()=>document.getElementById('total-saved').textContent==='0.071');checks.push('UI matured withdrawal transfers real local test ETH and closes goal');
  const config=await(await fetch('http://127.0.0.1:5001/api/config')).json();
  const hist=await(await fetch('http://127.0.0.1:5001/api/transactions?address='+accounts[0])).json();
  const withdraw=hist.transactions.find(x=>x.kind==='Withdrawn');const receipt=await rpc('eth_getTransactionReceipt',[withdraw.hash]);const gas=JSON.parse(fs.readFileSync(path.join(root,'tests/gas-results.json')));gas.gasUsed.withdraw=Number(BigInt(receipt.gasUsed));fs.writeFileSync(path.join(root,'tests/gas-results.json'),JSON.stringify(gas,null,2));
  await page.screenshot({path:path.join(evidence,'05-withdraw-confirmed-local-chain.png'),fullPage:true});
  await page.locator('#new-goal').click();await page.locator('#goal-name').fill('Blockchain security course');await page.locator('#goal-target').fill('0.04');
  const timestamp=Date.now()+7*86400000;const local=await page.evaluate(t=>{const d=new Date(t);return new Date(t-d.getTimezoneOffset()*60000).toISOString().slice(0,16);},timestamp);
  await page.locator('#goal-date').fill(local);await page.locator('#lock-consent').check();await page.screenshot({path:path.join(evidence,'06-create-goal-form.png'),fullPage:true});await page.locator('#goal-form button[type=submit]').click();
  await page.waitForFunction(()=>document.getElementById('feedback').textContent.startsWith('Goal created confirmed.'),{},{timeout:30000});await page.waitForFunction(()=>document.querySelectorAll('.goal-card').length===4);checks.push('Create goal form writes a new goal on the local chain');
  await page.evaluate(()=>window.qaWallet.network('0x1'));await page.waitForFunction(()=>document.getElementById('new-goal').disabled);checks.push('Wrong network disables writes');
  await page.locator('#connect').click();await page.waitForFunction(()=>!document.getElementById('new-goal').disabled);checks.push('Network switch restores writes');
  await page.evaluate(()=>window.qaWallet.change(1));await page.waitForFunction(()=>document.querySelectorAll('.goal-card').length===0);checks.push('Account switch clears previous owner data');
  await page.evaluate(()=>window.qaWallet.change(0));await page.waitForFunction(()=>document.querySelectorAll('.goal-card').length===4);
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(evidence,'07-mobile-local-chain.png'),fullPage:true});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));checks.push('390px mobile layout has no horizontal page overflow');
  await page.reload();await page.locator('#connect').click();await page.waitForFunction(()=>document.querySelectorAll('.goal-card').length===4);checks.push('Reload recovers persisted on-chain state');
  assert.deepEqual(errors,[]);checks.push('No uncaught browser errors');
  fs.writeFileSync(path.join(root,'tests/browser-results.json'),JSON.stringify({environment:'Headless Chromium, local Ganache chain 1337, injected test wallet (not MetaMask)',passed:checks.length,checks,errors,contractAddress:config.contractAddress},null,2));
  console.log(JSON.stringify({passed:checks.length,checks},null,2));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1);});
