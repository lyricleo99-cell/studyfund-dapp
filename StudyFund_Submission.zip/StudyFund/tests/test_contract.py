import json
import subprocess
from pathlib import Path

import pytest
from web3.exceptions import ContractLogicError, Web3RPCError

REVERT = (ContractLogicError, Web3RPCError, ValueError)
ROOT = Path(__file__).resolve().parents[1]


def test_create_and_event(w3, fund, owner, make_goal):
    goal_id, unlock = make_goal()
    g = fund.functions.getGoal(goal_id).call()
    assert tuple(g) == (owner, unlock, False, 10**18, 0, 'Textbooks')
    assert fund.functions.goalCount(owner).call() == 1
    assert fund.functions.goalIdAt(owner, 0).call() == goal_id
    events = fund.events.GoalCreated.get_logs(from_block=0)
    assert events[0]['args']['owner'] == owner


@pytest.mark.parametrize('name,target,delay', [('',1,60),('a'*65,1,60),('中文'*11,1,60),('x',0,60),('x',1,-1),('x',1,3650*86400+60)])
def test_invalid_goal_reverts(fund, make_goal, name, target, delay):
    with pytest.raises(REVERT):
        make_goal(name, target, delay)
    assert fund.functions.nextGoalId().call() == 0


def test_deposit_accounting_and_event(w3, fund, owner, make_goal):
    goal_id,_ = make_goal()
    tx = fund.functions.deposit(goal_id).transact({'from':owner,'value':123456789012345678})
    receipt = w3.eth.wait_for_transaction_receipt(tx)
    assert fund.functions.getGoal(goal_id).call()[4] == 123456789012345678
    assert w3.eth.get_balance(fund.address) == 123456789012345678
    assert fund.events.Deposited().process_receipt(receipt)[0]['args']['amount'] == 123456789012345678


def test_zero_deposit(fund, owner, make_goal):
    goal_id,_ = make_goal()
    with pytest.raises(REVERT):
        fund.functions.deposit(goal_id).transact({'from':owner,'value':0})


@pytest.mark.parametrize('operation', ['deposit','withdraw'])
def test_nonowner_blocked(w3, fund, make_goal, operation):
    goal_id,_ = make_goal()
    args={'from':w3.eth.accounts[1]}
    if operation == 'deposit': args['value']=1
    with pytest.raises(REVERT):
        getattr(fund.functions,operation)(goal_id).transact(args)


@pytest.mark.parametrize('operation', ['deposit','withdraw','getGoal'])
def test_nonexistent_goal(fund, owner, operation):
    with pytest.raises(REVERT):
        fn=getattr(fund.functions,operation)(999)
        if operation=='getGoal': fn.call()
        else: fn.transact({'from':owner})


def test_target_does_not_unlock_early(fund, owner, make_goal):
    goal_id,_=make_goal(target=1)
    fund.functions.deposit(goal_id).transact({'from':owner,'value':100})
    with pytest.raises(REVERT): fund.functions.withdraw(goal_id).transact({'from':owner})
    assert fund.functions.getGoal(goal_id).call()[4]==100


def test_withdraw_below_target_and_no_double_spend(w3,fund,owner,make_goal,advance):
    goal_id,_=make_goal(delay=60)
    amount=10**16
    fund.functions.deposit(goal_id).transact({'from':owner,'value':amount})
    advance(61)
    before=w3.eth.get_balance(owner)
    receipt=w3.eth.wait_for_transaction_receipt(fund.functions.withdraw(goal_id).transact({'from':owner}))
    assert w3.eth.get_balance(owner)==before+amount-receipt.gasUsed*receipt.effectiveGasPrice
    assert tuple(fund.functions.getGoal(goal_id).call()[2:5])==(True,10**18,0)
    assert fund.events.Withdrawn().process_receipt(receipt)[0]['args']['amount']==amount
    with pytest.raises(REVERT):fund.functions.withdraw(goal_id).transact({'from':owner})
    with pytest.raises(REVERT):fund.functions.deposit(goal_id).transact({'from':owner,'value':1})


def test_empty_withdraw(fund,owner,make_goal,advance):
    goal_id,_=make_goal(delay=60);advance(61)
    with pytest.raises(REVERT):fund.functions.withdraw(goal_id).transact({'from':owner})


def test_goals_and_wallets_isolated(w3,fund,owner,make_goal,advance):
    first,_=make_goal(delay=60);second,_=make_goal(sender=w3.eth.accounts[1])
    fund.functions.deposit(first).transact({'from':owner,'value':11})
    fund.functions.deposit(second).transact({'from':w3.eth.accounts[1],'value':23})
    advance(61);fund.functions.withdraw(first).transact({'from':owner})
    assert fund.functions.getGoal(second).call()[4]==23
    assert w3.eth.get_balance(fund.address)==23


def test_plain_transfer_rejected(w3,fund,owner):
    with pytest.raises(REVERT):w3.eth.send_transaction({'from':owner,'to':fund.address,'value':1})


@pytest.fixture(scope='module')
def receiver_artifact():
    script="""const fs=require('fs'),solc=require('solc');const s=fs.readFileSync(process.argv[1],'utf8');const o=JSON.parse(solc.compile(JSON.stringify({language:'Solidity',sources:{'Receiver.sol':{content:s}},settings:{evmVersion:'paris',outputSelection:{'*':{'*':['abi','evm.bytecode.object']}}}})));console.log(JSON.stringify(o.contracts['Receiver.sol'].Receiver));"""
    return json.loads(subprocess.check_output(['node','-e',script,str(ROOT/'tests/Receiver.sol')],text=True))


@pytest.mark.parametrize('reject,attack',[(True,False),(False,True)])
def test_receiver_failure_and_reentrancy(w3,fund,owner,advance,receiver_artifact,reject,attack):
    a=receiver_artifact
    factory=w3.eth.contract(abi=a['abi'],bytecode='0x'+a['evm']['bytecode']['object'])
    r=w3.eth.wait_for_transaction_receipt(factory.constructor(fund.address).transact({'from':owner}))
    receiver=w3.eth.contract(address=r.contractAddress,abi=a['abi'])
    receiver.functions.setup(w3.eth.get_block('latest').timestamp+60).transact({'from':owner,'value':1000})
    receiver.functions.setMode(reject,attack).transact({'from':owner});advance(61)
    if reject:
        with pytest.raises(REVERT):receiver.functions.withdraw().transact({'from':owner})
        assert fund.functions.getGoal(0).call()[4]==1000
        assert not fund.functions.getGoal(0).call()[2]
        receiver.functions.setMode(False,False).transact({'from':owner})
    receiver.functions.withdraw().transact({'from':owner})
    assert not receiver.functions.reentrySucceeded().call()
    assert w3.eth.get_balance(receiver.address)==1000
    assert w3.eth.get_balance(fund.address)==0
