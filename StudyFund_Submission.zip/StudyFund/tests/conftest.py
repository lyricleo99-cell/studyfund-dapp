import json
import os
from pathlib import Path
import subprocess
import sys
import time

import pytest
from web3 import Web3

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


@pytest.fixture(scope='session')
def w3():
    env = dict(os.environ, TEST_RPC_PORT='18546')
    process = subprocess.Popen(['node', str(ROOT / 'scripts/local-chain.cjs')], env=env,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    client = Web3(Web3.HTTPProvider('http://127.0.0.1:18546', request_kwargs={'timeout': 3}))
    try:
        for _ in range(80):
            if client.is_connected():
                break
            if process.poll() is not None:
                raise RuntimeError('Test chain did not start. Run npm install first; port 18546 must be free.')
            time.sleep(.1)
        else:
            raise RuntimeError('Local test chain startup timed out')
        assert client.eth.chain_id == 1337
        yield client
    finally:
        process.terminate()
        process.wait(timeout=10)


@pytest.fixture
def fund(w3):
    artifact = json.loads((ROOT / 'artifacts/StudyFund.json').read_text())
    factory = w3.eth.contract(abi=artifact['abi'], bytecode=artifact['bytecode'])
    receipt = w3.eth.wait_for_transaction_receipt(factory.constructor().transact({'from':w3.eth.accounts[0]}))
    return w3.eth.contract(address=receipt.contractAddress, abi=artifact['abi'])


@pytest.fixture
def owner(w3):
    return w3.eth.accounts[0]


@pytest.fixture
def make_goal(w3, fund, owner):
    def make(name='Textbooks', target=10**18, delay=3600, sender=None):
        sender = sender or owner
        goal_id = fund.functions.nextGoalId().call()
        unlock = w3.eth.get_block('latest').timestamp + delay
        tx = fund.functions.createGoal(name, target, unlock).transact({'from':sender})
        w3.eth.wait_for_transaction_receipt(tx)
        return goal_id, unlock
    return make


@pytest.fixture
def advance(w3):
    def run(seconds):
        w3.provider.make_request('evm_increaseTime', [seconds])
        w3.provider.make_request('evm_mine', [])
    return run
