import pytest
from app import create_app


@pytest.fixture
def client(w3,fund):
    return create_app({'TESTING':True,'CONTRACT_ADDRESS':fund.address,'CHAIN_ID':1337,'DEPLOYMENT_BLOCK':0,'LOG_BLOCK_RANGE':1000},w3).test_client()


def test_page_and_security_headers(client):
    r=client.get('/')
    assert r.status_code==200 and b'StudyFund' in r.data
    assert r.headers['X-Frame-Options']=='DENY'
    assert "script-src 'self'" in r.headers['Content-Security-Policy']


def test_config_hides_rpc(client):
    data=client.get('/api/config').json
    assert data['configured'] and data['chainId']==1337
    assert 'RPC_URL' not in str(data) and 'privateKey' not in str(data)


def test_health_and_readiness(client):
    assert client.get('/health').status_code==200
    assert client.get('/api/status').json['ready']


@pytest.mark.parametrize('url',['/api/goals','/api/goals?address=bad','/api/transactions?address=bad'])
def test_bad_address(client,url):
    assert client.get(url).status_code==400


@pytest.mark.parametrize('query',['limit=0','limit=51','offset=-1','offset=abc'])
def test_bad_pagination(client,owner,query):
    assert client.get(f'/api/goals?address={owner}&{query}').status_code==400


def test_goals_pagination_and_integer_precision(client,owner,make_goal,fund):
    a,_=make_goal();make_goal('Course')
    fund.functions.deposit(a).transact({'from':owner,'value':123456789012345678})
    data=client.get(f'/api/goals?address={owner}&limit=1').json
    assert data['total']==2 and data['nextOffset']==1
    assert data['goals'][0]['balanceWei']=='123456789012345678'
    data=client.get(f'/api/goals?address={owner}&offset=1').json
    assert data['goals'][0]['name']=='Course' and data['nextOffset'] is None


def test_history_filtered_sorted_and_complete(client,w3,owner,make_goal,fund,advance):
    a,_=make_goal(delay=60);make_goal('Someone else',sender=w3.eth.accounts[1])
    fund.functions.deposit(a).transact({'from':owner,'value':123});advance(61)
    fund.functions.withdraw(a).transact({'from':owner})
    events=client.get(f'/api/transactions?address={owner}').json['transactions']
    assert [e['kind'] for e in events]==['Withdrawn','Deposited','GoalCreated']
    assert events[0]['amountWei']=='123' and events[0]['hash'].startswith('0x')


def test_cursor_can_scan_all_blocks(w3,fund,owner,make_goal):
    make_goal()
    client=create_app({'TESTING':True,'CONTRACT_ADDRESS':fund.address,'CHAIN_ID':1337,'LOG_BLOCK_RANGE':2},w3).test_client()
    url=f'/api/transactions?address={owner}';seen=[]
    for _ in range(500):
        data=client.get(url).json;seen.extend(data['transactions'])
        if data['nextBefore'] is None:break
        url=f'/api/transactions?address={owner}&before={data["nextBefore"]}'
    assert len(seen)==1 and seen[0]['kind']=='GoalCreated'


def test_history_invalid_cursor(client,owner):
    assert client.get(f'/api/transactions?address={owner}&before=-1').status_code==400


def test_deployment_disabled(client):
    assert client.get('/deploy').status_code==404
    assert client.get('/api/deployment-artifact').status_code==404


def test_unconfigured_is_honest():
    client=create_app({'TESTING':True,'RPC_URL':'','CONTRACT_ADDRESS':''}).test_client()
    assert not client.get('/api/config').json['configured']
    assert client.get('/api/status').status_code==503


def test_wrong_chain_and_no_code(w3,fund,owner):
    for settings,code in [({'CONTRACT_ADDRESS':fund.address,'CHAIN_ID':11155111},'wrong_chain'),({'CONTRACT_ADDRESS':owner,'CHAIN_ID':1337},'no_contract')]:
        client=create_app(settings,w3).test_client()
        assert client.get('/api/status').json['error']==code


def test_rpc_failure_does_not_leak_secrets(w3,fund,monkeypatch):
    client=create_app({'CONTRACT_ADDRESS':fund.address,'CHAIN_ID':1337},w3).test_client()
    def fail(*args,**kwargs):raise Exception('https://secret-key@rpc.example')
    monkeypatch.setattr(w3.eth,'get_code',fail)
    r=client.get('/api/status')
    assert r.status_code==503 and b'secret-key' not in r.data
