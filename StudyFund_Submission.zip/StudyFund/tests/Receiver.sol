// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;
interface IFund {
    function createGoal(string calldata, uint256, uint64) external returns (uint256);
    function deposit(uint256) external payable;
    function withdraw(uint256) external;
}
contract Receiver {
    IFund public fund;
    uint256 public id;
    bool public reject;
    bool public attack;
    bool public reentrySucceeded;
    constructor(address address_) { fund = IFund(address_); }
    function setup(uint64 when) external payable {
        id = fund.createGoal("Receiver", 1 ether, when);
        fund.deposit{value: msg.value}(id);
    }
    function setMode(bool reject_, bool attack_) external { reject=reject_; attack=attack_; }
    function withdraw() external { fund.withdraw(id); }
    receive() external payable {
        require(!reject, "reject transfer");
        if (attack) { (reentrySucceeded, ) = address(fund).call(abi.encodeCall(IFund.withdraw, (id))); }
    }
}
