# Deployment and submission checklist

## Current deployment record

| Required item | Verified status |
|---|---|
| Local Solidity/Flask integration | Passed |
| Local browser transaction flow | Passed using a test wallet adapter |
| Sepolia contract address | **Not deployed yet** |
| Sepolia deployment transaction | **Not available yet** |
| Real MetaMask extension check | **Pending** |
| Public Render URL | **Live:** https://studyfund-dapp.onrender.com |
| Public GitHub repository | https://github.com/lyricleo99-cell/studyfund-dapp |

These are intentionally not replaced by sample addresses or invented URLs.

## Existing live deployment

The Render free service is already running from the public repository above. The repository contains the complete source archive plus a root deployment wrapper. Render expands `StudyFund_Submission.zip` during build and runs Gunicorn from `StudyFund/`.

Actual build command: `python -m zipfile -e StudyFund_Submission.zip . && pip install -r StudyFund/requirements.txt`

Actual start command: `gunicorn --chdir StudyFund app:app --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 120`

Open **https://studyfund-dapp.onrender.com/deploy** in a browser with MetaMask to deploy the contract. After the wallet confirms, record CONTRACT_ADDRESS and DEPLOYMENT_BLOCK, set these plus RPC_URL in the existing Render service environment, and set ENABLE_DEPLOY_UI=false. Redeploy and perform the real-wallet smoke test. Do not create another web service.

## 1. Prepare MetaMask and Sepolia

Install/open MetaMask in your own browser. Select Ethereum Sepolia (chain ID 11155111, hex 0xaa36a7) and obtain test ETH using a Sepolia faucet. You need gas for deployment and each write, plus the amount you want to deposit. Do not use Ethereum mainnet. Never send a recovery phrase or private key to anyone or put it into Render variables.

Obtain a Sepolia HTTPS RPC endpoint from a provider. Keep API-key-bearing endpoints in `.env` and Render environment settings, not public source code. The server does not expose this endpoint to the browser.

## 2. Deploy the exact included contract with your wallet

Start the app as described in README. In your local `.env`, set:

```text
ENABLE_DEPLOY_UI=true
CHAIN_ID=11155111
```

Restart Flask and visit `http://127.0.0.1:5000/deploy` in the browser where MetaMask is installed. Click **Connect & deploy on Sepolia**. Review and approve the deployment in MetaMask. The helper uses the included compiled ABI and bytecode; it never asks for a private key.

After confirmation it displays `CONTRACT_ADDRESS`, `DEPLOYMENT_BLOCK`, `CHAIN_ID` and the transaction hash. Save these values in your local `.env` and add `RPC_URL`. Set `ENABLE_DEPLOY_UI=false`, then restart Flask. Confirm `/api/status` returns `ready: true` and the dashboard's View contract link opens the expected Sepolia address.

Alternative: deploy `contracts/StudyFund.sol` in Remix with compiler **0.8.30**, optimization enabled **200 runs**, EVM **Paris**, environment **Injected Provider - MetaMask**, network **Sepolia**. Deploy `StudyFund` with no constructor arguments. Use the compiler-generated ABI supplied here only when these source/settings match.

## 3. Run a real-wallet smoke test

Connect MetaMask to the dashboard. Create a small goal with an unlock time at least a few minutes ahead. Deposit a small amount of test ETH and save the transaction hash. Check the goal balance and event history. Confirm the withdrawal control is locked before maturity. After the unlock time, click Refresh, withdraw and verify the goal closes and the wallet receives the balance less gas. Check each receipt in Sepolia Etherscan. Record wallet rejection, wrong-network and invalid-input behavior too.

Replace or supplement the local screenshots with the actual Sepolia and MetaMask screenshots. Do not claim the provided local pictures prove a testnet deployment.

## 4. Deploy Flask on Render

1. Put the contents of the `StudyFund` directory in a GitHub repository. Include ABI, artifacts and `static/vendor/ethers.umd.min.js`. Exclude `.env`, virtual environments and `node_modules`.
2. Sign in to Render and create a **Web Service** from that repository, or use its **Blueprint** flow with `render.yaml`.
3. If the repository contains a surrounding `StudyFund` directory, set Root Directory to that directory. If these files are at repository root, leave Root Directory blank.
4. Choose the Python runtime. Build command: `pip install -r requirements.txt`.
5. Start command: `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 120`.
6. Set Python version to `3.11.11`. Set `RPC_URL`, the actual `CONTRACT_ADDRESS`, actual `DEPLOYMENT_BLOCK`, `CHAIN_ID=11155111`, `LOG_BLOCK_RANGE=1000` and `ENABLE_DEPLOY_UI=false`.
7. Set the health check path to `/health`. Deploy, wait for a successful build, and copy the **actual Render-provided HTTPS URL** into the record below. Check `/api/status` separately for blockchain readiness.
8. Open the HTTPS site with MetaMask, connect, and repeat a small transaction. Confirm static files, wallet interaction, history and phone layout work from the public URL.

Render's available service plans and resource limits depend on the account. Do not purchase a plan without deciding that explicitly. A sleeping free service may take time to start; refresh after it wakes. The runtime requires only Python dependencies; do not run the local test chain on Render.

Official instructions: https://render.com/docs/deploy-flask and https://render.com/docs/web-services

## 5. Fill the final record after deployment

```text
Render URL: https://studyfund-dapp.onrender.com
Sepolia contract address: pending actual deployment
Deployment block: pending actual deployment
Deployment transaction hash: pending actual deployment
Successful deposit hash: pending real-wallet test
Successful withdrawal hash: pending real-wallet test
Web deployment verified: 13 October 2026; Sepolia verification pending
```

Then update the report's deployment status and add your name/student number if required. Submit the PDF, source code, Solidity file, ABI, Flask file, HTML/CSS/JS, screenshots and Render URL. A video is not required.

## Troubleshooting

| Symptom | Action |
|---|---|
| Setup banner / configuration unavailable | Check RPC URL and address; restart after editing `.env` |
| No contract at address | Verify Sepolia, address and deployment receipt |
| Wrong network | Click the wallet-address button to request the correct network |
| History says no events | Scan older blocks; verify DEPLOYMENT_BLOCK is the deployment block |
| RPC rejects log range | Lower LOG_BLOCK_RANGE to the provider's supported range |
| Render is healthy but no blockchain data | `/health` is only liveness; inspect `/api/status` and environment settings |
| Pending confirmation after timeout | Check the transaction in Etherscan; do not blindly resubmit |
| Goal seems mature but remains locked | Refresh to fetch a new block timestamp; local wall-clock time is not authoritative |
| Unable to withdraw from a contract-wallet goal | Recipient must accept native ETH; test failure recovery is covered locally |
